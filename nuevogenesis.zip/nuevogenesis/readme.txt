Business lite is a Free Premium WordPress theme designed by CyberChimps.com in California.

Theme Homepage -  http://cyberchimps.com/businesslite

Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

Blog icons provided by http://glyphicons.com/ under the Creative Commons license.

Foundation and Orbit are licensed under the MIT license - http://www.opensource.org/licenses/mit-license.php

---------------------------------------------------------------------------
---------------------------------------------------------------------------

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com//docs/

For the support forum please visit: http://cyberchimps.com/forum/

For more support options please visit http://cyberchimps.com/support/


