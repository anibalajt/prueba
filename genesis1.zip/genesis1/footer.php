<footer id="footer">
<div>
    <div style="float: left;padding: 43px 15px;">
        <li><span>Seguinos: </span></li>
        <li></li>
        <li></li>
    </div>
    <div style="float: right;padding: 43px 25px;">
        <span>
            ©2013 Génesis Profesional, Todos los Derechos Deservados
        </span>
    </div>
</div> 
</footer>    
</body>
</html>