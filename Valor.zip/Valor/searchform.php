<div id="search">
	<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	    <div>
	        <input type="text" value="" name="s" id="s" />
	        <input type="submit" id="searchsubmit" value="Search" />
	    </div>
	</form>
</div>
<div class='clear'></div>	
