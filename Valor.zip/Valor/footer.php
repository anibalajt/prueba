<div class='clear'></div>
</div>

<div id="bottom">
	<ul>

	<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar("Footer") ) : ?>  
	
	<?php endif; ?>
	
	</ul>
	<div class='clear'></div>
</div>

<div id="footer">
<div style="width: 142px;float: left;color: #000000;    font-size: 15px;padding: 0 15px;">
        <span style="float: left;line-height: 2;">Seguinos: </span>
	<div><img width="30px" height="30px" src="http://ejfstudios.com.ar/genesis/wordpress/wp-content/uploads/2013/02/faceb.png">
<img width="30px" height="30px"style="
    position: relative;
" src="http://ejfstudios.com.ar/genesis/wordpress/wp-content/uploads/2013/02/twir.png"></div>
    </div>
	<div class="fcred">
		 © 2013 Génesis Profesional. Todos los Derechos Reservados
		<p style="text-align: left;">Powered by: Neolo.com</p>
	</div>	
<div class='clear'></div>	
<?php wp_footer(); ?>
</div>
<div class='clear'></div>	
</div>
</body>
</html>      